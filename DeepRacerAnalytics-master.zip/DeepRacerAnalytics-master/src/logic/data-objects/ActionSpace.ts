interface ActionSpace {
    speed: number;
    steering_angle: number;
    index: number;
}

export default ActionSpace;
