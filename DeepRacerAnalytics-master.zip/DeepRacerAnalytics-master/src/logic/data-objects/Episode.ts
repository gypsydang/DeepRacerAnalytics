import Step from './Step';

interface Episode {
    steps: Step[];
}

export default Episode;
